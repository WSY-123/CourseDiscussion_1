from django.apps import AppConfig


class DiscussConfig(AppConfig):
    name = 'discuss'
